-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         5.7.17-log - MySQL Community Server (GPL)
-- SO del servidor:              Win32
-- HeidiSQL Versión:             10.2.0.5599
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Volcando estructura de base de datos para res_hoteles
CREATE DATABASE IF NOT EXISTS `res_hoteles` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `res_hoteles`;

-- Volcando estructura para tabla res_hoteles.comentario_hotel
CREATE TABLE IF NOT EXISTS `comentario_hotel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(1000) NOT NULL,
  `fecha` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `id_hotel` int(11) NOT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uidx_comentario_usuario` (`id_usuario`),
  KEY `fk_comentario` (`id_hotel`),
  CONSTRAINT `fk_comentario` FOREIGN KEY (`id_hotel`) REFERENCES `hoteles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_usuario_comentario` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla res_hoteles.comentario_hotel: ~4 rows (aproximadamente)
/*!40000 ALTER TABLE `comentario_hotel` DISABLE KEYS */;
INSERT INTO `comentario_hotel` (`id`, `descripcion`, `fecha`, `id_hotel`, `id_usuario`) VALUES
	(1, 'Todo excelente, servicio de primerísimo nivel, empleados preparados y capacitados para desarrollar s', '2019-09-17 14:49:16', 1, 1),
	(2, 'Este establecimiento dispone de canchas de tenis techadas y parque acuático gratuito con toboganes. El establecimiento cuenta con una alberca al aire libre y un chapoteadero. Otras opciones de esparcimiento incluyen sauna y sala de fitness. Las siguientes actividades de recreación se pueden practicar en el establecimiento o en los alrededores. Es posible que apliquen cargos.', '2019-09-17 14:55:59', 1, 2),
	(5, 'Todo excelente, servicio de primerísimo nivel, empleados preparados y capacitados para desarrollar s', '2019-10-01 00:00:00', 1, 6),
	(6, 'Este establecimiento dispone de canchas de tenis techadas y parque acuático gratuito con toboganes. El establecimiento cuenta con una alberca al aire libre y un chapoteadero. Otras opciones de esparcimiento incluyen sauna y sala de fitness. Las siguientes actividades de recreación se pueden practicar en el establecimiento o en los alrededores. Es posible que apliquen cargos.\r\n\r\n', '2019-10-01 00:00:00', 1, 8);
/*!40000 ALTER TABLE `comentario_hotel` ENABLE KEYS */;

-- Volcando estructura para tabla res_hoteles.email_hotel
CREATE TABLE IF NOT EXISTS `email_hotel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `id_hotel` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_email_hotel` (`id_hotel`),
  CONSTRAINT `fk_email_hotel` FOREIGN KEY (`id_hotel`) REFERENCES `hoteles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla res_hoteles.email_hotel: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `email_hotel` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_hotel` ENABLE KEYS */;

-- Volcando estructura para tabla res_hoteles.foto_hotel
CREATE TABLE IF NOT EXISTS `foto_hotel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `foto` varchar(500) NOT NULL,
  `id_hotel` int(11) NOT NULL,
  `imagen_principal` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_foto_hotel` (`id_hotel`),
  CONSTRAINT `fk_foto_hotel` FOREIGN KEY (`id_hotel`) REFERENCES `hoteles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla res_hoteles.foto_hotel: ~13 rows (aproximadamente)
/*!40000 ALTER TABLE `foto_hotel` DISABLE KEYS */;
INSERT INTO `foto_hotel` (`id`, `foto`, `id_hotel`, `imagen_principal`) VALUES
	(1, '../view/asset/riu3.jpg', 1, 'not'),
	(5, '../view/asset/riu2.jpg', 2, 'active'),
	(6, '../view/asset/riu.jpg', 2, 'not'),
	(9, '../view/asset/ham2.jpg', 3, 'active'),
	(10, '../view/asset/riu3.jpg', 1, 'active'),
	(11, '../view/asset/riu2.jpg', 1, 'not'),
	(14, '../view/asset/64-swimming-pool-4-hotel-barcelo-santo-domingo_tcm7-38673.jpg', 6, 'active'),
	(15, '../view/asset/03764399_gp.jpeg', 6, 'not'),
	(16, '../view/asset/158964832.jpg', 6, 'not'),
	(17, '../view/asset/0c255ea13de42f5453de9902a2ebd467.jpg', 8, 'active'),
	(19, '../view/asset/05854ee3f836e82a21ea635302c06a56.jpg', 9, 'active'),
	(20, '../view/asset/water-park-v18271468-1440-1024x683.jpg', 9, 'not'),
	(21, '../view/asset/slide-16.jpg', 1, 'not');
/*!40000 ALTER TABLE `foto_hotel` ENABLE KEYS */;

-- Volcando estructura para tabla res_hoteles.habitaciones
CREATE TABLE IF NOT EXISTS `habitaciones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `precio` double NOT NULL,
  `precio_oferta` double NOT NULL,
  `tipo` varchar(100) NOT NULL,
  `cant_cama` int(11) NOT NULL,
  `tamaño` varchar(100) DEFAULT NULL,
  `cant_adulto` int(11) NOT NULL,
  `cant_niño` int(11) NOT NULL,
  `detalle` varchar(500) DEFAULT NULL,
  `disponibilidad` tinyint(1) NOT NULL,
  `id_hotel` int(11) NOT NULL,
  `foto` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_habitaciones_hotel` (`id_hotel`),
  CONSTRAINT `fk_habitaciones_hotel` FOREIGN KEY (`id_hotel`) REFERENCES `hoteles` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla res_hoteles.habitaciones: ~4 rows (aproximadamente)
/*!40000 ALTER TABLE `habitaciones` DISABLE KEYS */;
INSERT INTO `habitaciones` (`id`, `precio`, `precio_oferta`, `tipo`, `cant_cama`, `tamaño`, `cant_adulto`, `cant_niño`, `detalle`, `disponibilidad`, `id_hotel`, `foto`) VALUES
	(1, 2000, 1500, 'Junior Suit', 2, '100', 2, 2, 'Alimentos y bebidas: cafetera y tetera, minibar, servicio de habitación las 24 horas con botella de agua de cortesía', 5, 1, '../view/asset/ha1.jpg'),
	(6, 5000, 4500, 'Siut Precidencial ', 1, '200', 1, 1, 'Baño: baño privado con tina y regadera combinadas, amenidades de baño de diseñador y secadora de cabello', 5, 1, '../view/asset/ha3.jpg'),
	(12, 560, 550, 'Flat Swim-Up suite', 2, NULL, 2, 2, '1 cama de matrimonio grande y 1 sofá cama doble o 2 camas dobles y 1 sofá cama doble.\r\n\r\nHabitación de 45 metros cuadrados con balcón o patio y vista a la piscina.\r\n\r\nInternet - WiFi gratis', 1, 9, '../view/asset/Nickelodeon-Resort-Punta-Cana-003-1024x1024.jpg'),
	(13, 3500, 3000, 'Swank Plunge Pool Suite', 2, '1025', 2, 2, 'Esto es una prueba', 1, 9, '../view/asset/7419d042_5bbd_4ea1_98bc_64c9a121a797.jpg');
/*!40000 ALTER TABLE `habitaciones` ENABLE KEYS */;

-- Volcando estructura para tabla res_hoteles.hoteles
CREATE TABLE IF NOT EXISTS `hoteles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `provincia` varchar(100) NOT NULL,
  `calle` varchar(50) NOT NULL,
  `prestigio` int(11) NOT NULL,
  `localizacion` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uidx_hotel_nombre` (`nombre`),
  FULLTEXT KEY `ftindex_hoteles` (`nombre`,`provincia`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla res_hoteles.hoteles: ~6 rows (aproximadamente)
/*!40000 ALTER TABLE `hoteles` DISABLE KEYS */;
INSERT INTO `hoteles` (`id`, `nombre`, `provincia`, `calle`, `prestigio`, `localizacion`) VALUES
	(1, 'Riu palace all exclusive', 'La Altagracia', 'D58', 5, 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3778.811311432005!2d-68.45630568527613!3d18.717263987294743!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8ea8ebbe2033a3db%3A0x5e15d739ded7ebfc!2sHotel%20Riu%20Palace%20Bavaro!5e0!3m2!1ses-419!2sdo!4v1568676842650!5m2!1ses-419!2sdo'),
	(2, 'Meliat', 'La Altagracia', '2', 6, 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3779.767754453506!2d-68.41021978527684!3d18.67441498731964!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8ea8ec956bfc8b47%3A0xa459a2528b9f4a49!2sMeli%C3%A1%20Caribe%20Beach%20Resort!5e0!3m2!1ses-419!2sdo!4v1568676901719!5m2!1ses-419!2sdo'),
	(3, 'Hamaca', 'Santo Domingo', 'Los prado', 4, 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3784.759009944115!2d-69.60620788528038!3d18.449247887450625!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8eaf7e38aef7e231%3A0x380afa2b57a05246!2sBe%20Live%20Experience%20Hamaca%20Beach!5e0!3m2!1ses-419!2sdo!4v1568676994710!5m2!1ses-419!2sdo'),
	(6, 'Barcelo premium resort', 'La Altagracia', 'principal', 5, 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d60467.817708204!2d-68.46926097473374!3d18.698132700177396!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8ea8ecc4d0b983a3%3A0xc6e6444192a8c569!2sBarcel%C3%B3%20B%C3%A1varo%20Palace!5e0!3m2!1ses-419!2sdo!4v1569614748105!5m2!1ses-419!2sdo'),
	(8, 'Grand Palladium', 'La Romana', 'Avenida Francia ', 5, 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3779.3337342980835!2d-68.42988068510469!3d18.69387098730828!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8ea8ec8109e1e367%3A0xb931947533c12528!2sGrand%20Palladium%20Punta%20Cana%20Resort%20%26%20Spa!5e0!3m2!1ses-419!2sdo!4v1569703242759!5m2!1ses-419!2sdo'),
	(9, 'Nickelodeon Hotels', 'La Altagracia', 'Punta Cana 23002', 6, 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3776.953099031934!2d-68.5766201851031!3d18.800243387246642!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8ea8c3ab20b4a127%3A0x4c9a4801bbdf4f37!2sNickelodeon%20Hotels%20%26%20Resorts%20Punta%20Cana!5e0!3m2!1ses-419!2sdo!4v1569876730636!5m2!1ses-419!2sdo');
/*!40000 ALTER TABLE `hoteles` ENABLE KEYS */;

-- Volcando estructura para tabla res_hoteles.lugares_cercanos_hotel
CREATE TABLE IF NOT EXISTS `lugares_cercanos_hotel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lugar` varchar(100) NOT NULL,
  `id_hotel` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_lugares_cercanos` (`id_hotel`),
  CONSTRAINT `fk_lugares_cercanos` FOREIGN KEY (`id_hotel`) REFERENCES `hoteles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla res_hoteles.lugares_cercanos_hotel: ~7 rows (aproximadamente)
/*!40000 ALTER TABLE `lugares_cercanos_hotel` DISABLE KEYS */;
INSERT INTO `lugares_cercanos_hotel` (`id`, `lugar`, `id_hotel`) VALUES
	(2, 'Playa macao', 1),
	(4, 'Campo de golf', 1),
	(5, 'Acuario', 2),
	(7, 'Parque acuático', 8),
	(10, 'Bomba de gasolina', 8),
	(11, 'Bomba de gasolina', 9),
	(12, 'Clinica Punta Cana', 9);
/*!40000 ALTER TABLE `lugares_cercanos_hotel` ENABLE KEYS */;

-- Volcando estructura para tabla res_hoteles.reservaciones
CREATE TABLE IF NOT EXISTS `reservaciones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `telefono` varchar(50) NOT NULL,
  `apellido` varchar(100) NOT NULL,
  `correo` varchar(100) NOT NULL,
  `check_in` date NOT NULL,
  `check_out` date NOT NULL,
  `fecha` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `cant_persona` int(11) NOT NULL,
  `precio_persona` double NOT NULL,
  `total` double NOT NULL,
  `id_habitacion` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_reservaciones_habitaciones` (`id_habitacion`),
  KEY `fk_reservaciones_usuarios` (`id_usuario`),
  CONSTRAINT `fk_reservaciones_habitaciones` FOREIGN KEY (`id_habitacion`) REFERENCES `habitaciones` (`id`),
  CONSTRAINT `fk_reservaciones_usuarios` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla res_hoteles.reservaciones: ~15 rows (aproximadamente)
/*!40000 ALTER TABLE `reservaciones` DISABLE KEYS */;
INSERT INTO `reservaciones` (`id`, `nombre`, `telefono`, `apellido`, `correo`, `check_in`, `check_out`, `fecha`, `cant_persona`, `precio_persona`, `total`, `id_habitacion`, `id_usuario`) VALUES
	(1, 'Engels', '809-809-8888', 'valdez', 'correo@coreo,com', '0000-00-00', '0000-00-00', '2019-09-25 21:42:54', 5, 1000, 1000, 1, 1),
	(2, 'engels', '829-514-5101', 'Valdez', 'engels.arquimedes@gmail.com', '2019-09-25', '2019-09-28', '2019-09-25 21:44:23', 2, 4500, 13500, 6, 2),
	(3, 'engels', '829-514-5101', 'Valdez', 'engels.arquimedes@gmail.com', '2019-09-25', '2019-09-28', '2019-09-25 21:48:03', 2, 4500, 13500, 6, 2),
	(4, 'engels', '829-514-5101', 'Valdez', 'engels.arquimedes@gmail.com', '2019-09-25', '2019-09-28', '2019-09-25 21:49:41', 2, 4500, 13500, 6, 2),
	(5, 'Juan', '829-514-5101', 'Valdez', 'engels.arquimedes@gmail.com', '2019-09-25', '2019-09-28', '2019-09-25 21:53:29', 2, 4500, 13500, 6, 2),
	(6, 'Juan', '829-514-5101', 'Valdez', 'engels.arquimedes@gmail.com', '2019-09-25', '2019-09-28', '2019-09-25 21:59:41', 3, 1500, 4500, 1, 2),
	(7, 'Juan', '829-514-5101', 'Valdez', 'engels.arquimedes@gmail.com', '2019-09-25', '2019-09-28', '2019-09-25 22:00:47', 3, 1500, 4500, 1, 2),
	(8, 'Sirvia', '829-514-5101', 'Castillo', 'engels.arquimedes@gmail.com', '2019-09-25', '2019-09-28', '2019-09-25 22:02:07', 2, 1500, 4500, 1, 2),
	(9, 'Sirvia', '829-514-5101', 'Castillo', 'engels.arquimedes@gmail.com', '2019-09-25', '2019-09-28', '2019-09-25 22:03:35', 2, 1500, 4500, 1, 2),
	(10, 'Sirvia', '829-514-5101', 'Castillo', 'engels.arquimedes@gmail.com', '2019-09-25', '2019-09-28', '2019-09-25 22:04:31', 2, 1500, 4500, 1, 2),
	(11, 'engels', '829-514-5101', 'Valdez', 'engels.arquimedes@gmail.com', '2019-09-26', '2019-09-27', '2019-09-25 23:25:48', 4, 1500, 1500, 1, 1),
	(12, 'engels', '829-514-5101', 'Valdez', 'engels.arquimedes@gmail.com', '2019-09-27', '2019-09-29', '2019-09-27 16:44:41', 2, 4500, 9000, 6, 1),
	(13, 'engels', '829-514-5101', 'Valdez', 'engels.arquimedes@gmail.com', '2019-09-29', '2019-09-30', '2019-09-29 18:25:55', 2, 1500, 1500, 1, 2),
	(14, 'engels', '829-514-5101', 'Valdez', 'engels.arquimedes@gmail.com', '2019-10-01', '2019-10-03', '2019-09-30 22:51:29', 2, 1500, 3000, 1, 1),
	(15, 'Admin', '829-514-5101', 'Admin', 'engels.arquimedes@gmail.com', '2019-10-03', '2019-10-13', '2019-10-03 12:53:11', 4, 550, 5500, 12, 1);
/*!40000 ALTER TABLE `reservaciones` ENABLE KEYS */;

-- Volcando estructura para tabla res_hoteles.servicio_hotel
CREATE TABLE IF NOT EXISTS `servicio_hotel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `servicio` varchar(100) NOT NULL,
  `id_hotel` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_servicios_hotel` (`id_hotel`),
  CONSTRAINT `fk_servicios_hotel` FOREIGN KEY (`id_hotel`) REFERENCES `hoteles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla res_hoteles.servicio_hotel: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `servicio_hotel` DISABLE KEYS */;
/*!40000 ALTER TABLE `servicio_hotel` ENABLE KEYS */;

-- Volcando estructura para tabla res_hoteles.tarjeta_credito
CREATE TABLE IF NOT EXISTS `tarjeta_credito` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `numero` varchar(19) NOT NULL,
  `expiracion` varchar(5) NOT NULL,
  `cvv` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_tarjeta_usuario` (`id_usuario`),
  CONSTRAINT `fk_tarjeta_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla res_hoteles.tarjeta_credito: ~2 rows (aproximadamente)
/*!40000 ALTER TABLE `tarjeta_credito` DISABLE KEYS */;
INSERT INTO `tarjeta_credito` (`id`, `nombre`, `numero`, `expiracion`, `cvv`, `id_usuario`) VALUES
	(1, 'admin', '1111-1111-1111-1111', '01/01', 123, 1),
	(2, 'juan', '2222-2222-2222-2222', '01/01', 456, 2);
/*!40000 ALTER TABLE `tarjeta_credito` ENABLE KEYS */;

-- Volcando estructura para tabla res_hoteles.tel_hotel
CREATE TABLE IF NOT EXISTS `tel_hotel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `telefono` varchar(50) NOT NULL,
  `id_hotel` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_tel_hotel` (`id_hotel`),
  CONSTRAINT `fk_tel_hotel` FOREIGN KEY (`id_hotel`) REFERENCES `hoteles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla res_hoteles.tel_hotel: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `tel_hotel` DISABLE KEYS */;
/*!40000 ALTER TABLE `tel_hotel` ENABLE KEYS */;

-- Volcando estructura para tabla res_hoteles.usuarios
CREATE TABLE IF NOT EXISTS `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `correo` varchar(100) NOT NULL,
  `clave` varchar(100) NOT NULL,
  `tipo` tinyint(4) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `apellido` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uidx_correo_usuario` (`correo`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla res_hoteles.usuarios: ~4 rows (aproximadamente)
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` (`id`, `correo`, `clave`, `tipo`, `nombre`, `apellido`) VALUES
	(1, 'admin@admin.com', '123456', 1, 'El administrados', 'Admin'),
	(2, 'juan@gmail.com', '123456', 2, 'Juan', 'Valdez'),
	(6, 'florangel@gmail.com', '123456', 2, 'Florangel', 'Abreu'),
	(8, 'engels@gmail.com', '123456', 1, 'Engels', 'Valdez Castillo');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;

-- Volcando estructura para vista res_hoteles.vw_hotel_sm
-- Creando tabla temporal para superar errores de dependencia de VIEW
CREATE TABLE `vw_hotel_sm` (
	`nombre` VARCHAR(100) NOT NULL COLLATE 'utf8_general_ci',
	`provincia` VARCHAR(100) NOT NULL COLLATE 'utf8_general_ci',
	`calle` VARCHAR(50) NOT NULL COLLATE 'utf8_general_ci',
	`prestigio` INT(11) NOT NULL,
	`foto` VARCHAR(500) NOT NULL COLLATE 'utf8_general_ci'
) ENGINE=MyISAM;

-- Volcando estructura para vista res_hoteles.vw_hotel_sm
-- Eliminando tabla temporal y crear estructura final de VIEW
DROP TABLE IF EXISTS `vw_hotel_sm`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_hotel_sm` AS select `hoteles`.`nombre` AS `nombre`,`hoteles`.`provincia` AS `provincia`,`hoteles`.`calle` AS `calle`,`hoteles`.`prestigio` AS `prestigio`,`foto_hotel`.`foto` AS `foto` from (`hoteles` join `foto_hotel` on((`hoteles`.`id` = `foto_hotel`.`id_hotel`))) where ((`hoteles`.`nombre` like '%a%') and (`hoteles`.`provincia` like '%a%')) group by `foto_hotel`.`foto`;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
